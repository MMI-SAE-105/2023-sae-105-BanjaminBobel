[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/kGMeGFDJ)
- NOM : Bobel
- PRÉNOM : Banjamin
- URL du site : isozakiarata.banjaminbobel.fr
- URL FIGMA : https://www.figma.com/file/ImgewadnBrUshc8FnpAAWS/SAE-105?type=design&node-id=322%3A1210&mode=design&t=LvysYpurW3nihQx9-1

# Structure de départ pour la SAE 105.

La structure de votre projet doit respecter scrupuleusement le modèle fourni dans ce dépôt (Repository).

## Contraintes :
[contraites d'intégration HTML / CSS / Alpine](https://moodle.univ-fcomte.fr/mod/page/view.php?id=645799)
